![GitHub last commit](https://img.shields.io/badge/Integrantes%20%3A%20-%20%237E7E73?cacheSeconds=7200
) ![GitHub code size in bytes](https://img.shields.io/badge/Bastian%20Mariangel%20-%20%2350CAC0?cacheSeconds=7200
)
![GitHub last commit](https://img.shields.io/badge/Ivan%20Mieres%20-%20%23D8DA31?cacheSeconds=7200
)
![GitHub last commit](https://img.shields.io/badge/Patricio%20Bonnin%20-%20%23E87215?cacheSeconds=7200
)
![GitHub last commit](https://img.shields.io/badge/Roberto%20Rivas%20-%20%23F70910?cacheSeconds=7200
)
![GitHub last commit](https://img.shields.io/badge/Angelica%20Romero%20-%20%23A613DB?color=rgba(181%2C%2028%2C%20230%2C%200.8)&cacheSeconds=7200
)

# Importante

## Integrantes

• Bastián Mariangel 

• Roberto Rivas 

• Iván Mieres 

• Patricio Bonnin 

• Angélica Romero

## Información de Archivos del proyecto

• Si desea conectarse a la base de datos del proyecto recuerde cambiar la contraseña y Usuario de MySQL
en el archivo application.yml en la ruta: 

src\main\java\resources\application.yml

• La base de datos se encuentra en :  src\main\resources\prev_riesgo.sql

