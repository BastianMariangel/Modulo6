package com.example.demo.config;


import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import java.io.IOException;


@Configuration
@EnableWebSecurity
public class WebSecurityConfig {

    // Autorizar por Rol

    @Bean
    public SecurityFilterChain securityFilterChainS(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests((authorizeHttpRequests) ->
                        authorizeHttpRequests
                                .requestMatchers(AntPathRequestMatcher.antMatcher(HttpMethod.GET,"/index")).permitAll()
                                .requestMatchers(AntPathRequestMatcher.antMatcher(HttpMethod.GET,"/login")).permitAll()
                                .requestMatchers(AntPathRequestMatcher.antMatcher(HttpMethod.GET,"/logout")).permitAll()
                                .requestMatchers(AntPathRequestMatcher.antMatcher(HttpMethod.POST,"/capacitacionBody")).permitAll()
                                .requestMatchers(AntPathRequestMatcher.antMatcher(HttpMethod.GET ,"/crearCapacitacion")).hasRole("CLIENTE")
                                .requestMatchers(AntPathRequestMatcher.antMatcher(HttpMethod.GET ,"/listaCapacitacion")).hasRole("CLIENTE")
                                .requestMatchers(AntPathRequestMatcher.antMatcher(HttpMethod.GET ,"/contacto")).hasRole("CLIENTE")
                                .requestMatchers(AntPathRequestMatcher.antMatcher(HttpMethod.GET ,"/registro")).hasRole("ADMINISTRATIVO")
                                .requestMatchers(AntPathRequestMatcher.antMatcher(HttpMethod.GET ,"/listaUsuarios")).hasRole("ADMINISTRATIVO")
                                .anyRequest().permitAll()
                )
                .formLogin((form) -> form
                        .loginPage("/login")
                        .permitAll()
                )
                .logout((logout) -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/index")
                        .permitAll()
                )
                .csrf(AbstractHttpConfigurer::disable);

        return http.build();
    }

    @Bean
    public UserDetailsService userDetailsService() {
        UserDetails userCliente = User.withDefaultPasswordEncoder()
                .username("userCliente")
                .password("password")
                .roles("CLIENTE")
                .build();

        UserDetails userProfesional = User.withDefaultPasswordEncoder()
                .username("userProfesional")
                .password("password")
                .roles("PROFESIONAL")
                .build();

        UserDetails userAdministrativo = User.withDefaultPasswordEncoder()
                .username("userAdministrativo")
                .password("password")
                .roles("ADMINISTRATIVO")
                .build();

        return new InMemoryUserDetailsManager(userCliente, userProfesional, userAdministrativo);
    }
}